-----
Wireless Java 2nd edition source code
February 25, 2003

Jonathan Knudsen
jknudsen@sprynet.com

- Building the source code using the J2ME Wireless Toolkit

Download the wj2-src.zip and unzip it into the wireless toolkit's
apps directory. In the toolkit, you can now open the wj2 project.
Click on Build to compile the project and Run to run the sample
code.

- Building the source code using Ant

Download wj2-src.zip and unzip it anywhere. Edit the build/build.xml
file to modify the "midp" and "ant" properties to point to your
installations of the toolkit and Ant. Open a command line, change
directories to the build directory, and type ant. Other targets
are also provided:
  - "run" runs the project in the toolkit emulator
  - "jad" adjusts the jar size attribute in the MIDlet suite descriptor
  - "clean" cleans up intermediate files

- Building the cryptographic source using Ant

Download wj2-crypto-src.zip and unzip it. You'll need Ant, ProGuard,
and the Bouncy Castle Cryptography APIs to build this project. You'll
have to copy the Bouncy Castle midp_classes.zip file and put it
in a lib subdirectory of the wj2-crypto project directory. Next,
edit build/build.xml to correctly set the "midp", "ant", and
"proguard" properties. In a command line window, change directories
to build and type "ant".

Because of U.S. export restrictions, the source code for
StealthMIDlet is not included in the download. You will need
to type it in yourself from the book.

- Where's the server?

By default, wj2 and wj2-crypto use a server hosted by Apress. If
you'd like to host your own servlets, the source code is provided
in wj2-server-src.zip and wj2-crypto-server-src.zip. Most of
the URLs used in the example code (with the exception of Jargoneer)
are defined as application properties in the application descriptor.
You can change most of the URLs by editing the descriptor.

Again, because of U.S. export restrictions, the source code
for StealthServlet is not included. You will need to enter it
yourself.

-----